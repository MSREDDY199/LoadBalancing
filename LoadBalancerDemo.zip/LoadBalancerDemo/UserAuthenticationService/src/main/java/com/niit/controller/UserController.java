package com.niit.controller;

import com.niit.model.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("/saveUser")
    public ResponseEntity<?> saveUser()
    {
        User user = new User();
        user.setUsername("rakesh");
        user.setPassword("india");
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
}
