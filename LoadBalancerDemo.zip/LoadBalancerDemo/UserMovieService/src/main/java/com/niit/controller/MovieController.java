package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@RestController
public class MovieController {

    @Autowired
    @LoadBalanced
    private RestTemplate restTemplate;

    @GetMapping("/register")
    public ResponseEntity<?> addMovie()throws RestClientException, IOException
    {
        System.out.println("in consumer");

        ResponseEntity<String> response=null;
        try{
            response=restTemplate.exchange("http://USER-AUTHENTICATION-SERVICE/saveUser",
                    HttpMethod.GET, getHeaders(),String.class);
        }catch (Exception ex)
        {
            System.out.println(ex);
        }
        System.out.println(response.getBody());
        return new ResponseEntity<>(response.getBody(),HttpStatus.OK);
    }

    private static HttpEntity<?> getHeaders() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}


